package com.example.signupvalidationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etName, etEmail, etPassword;
    AutoCompleteTextView autoCompleteCity;
    RadioGroup rgGender;
    Spinner spinnerCountry;
    CheckBox cbTerms;
    Button btnSubmit;

    String[] cities = {"Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata"};
    String[] countries = {"India", "USA", "UK", "Canada", "Australia"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        autoCompleteCity = findViewById(R.id.autoCompleteCity);
        rgGender = findViewById(R.id.rgGender);
        spinnerCountry = findViewById(R.id.spinnerCountry);
        cbTerms = findViewById(R.id.cbTerms);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Setup AutoCompleteTextView for cities
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, cities);
        autoCompleteCity.setAdapter(cityAdapter);

        // Setup Spinner for countries
        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, countries);
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCountry.setAdapter(countryAdapter);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Get values from input fields
                String name = etName.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString();
                String city = autoCompleteCity.getText().toString().trim();
                String country = spinnerCountry.getSelectedItem().toString();
                int selectedGenderId = rgGender.getCheckedRadioButtonId();

                // Validation
                if (name.isEmpty()) {
                    etName.setError("Name is required");
                    etName.requestFocus();
                    return;
                }

                if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    etEmail.setError("Valid email is required");
                    etEmail.requestFocus();
                    return;
                }

                if (password.isEmpty() || password.length() < 6) {
                    etPassword.setError("Password must be at least 6 characters");
                    etPassword.requestFocus();
                    return;
                }

                if (city.isEmpty()) {
                    autoCompleteCity.setError("City is required");
                    autoCompleteCity.requestFocus();
                    return;
                }

                if (selectedGenderId == -1) {
                    Toast.makeText(MainActivity.this, "Please select gender", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!cbTerms.isChecked()) {
                    Toast.makeText(MainActivity.this, "Please accept terms & conditions", Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton selectedGender = findViewById(selectedGenderId);
                String gender = selectedGender.getText().toString();

                // Move to DisplayActivity with collected data
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                intent.putExtra("city", city);
                intent.putExtra("gender", gender);
                intent.putExtra("country", country);
                startActivity(intent);
            }
        });
    }
}
