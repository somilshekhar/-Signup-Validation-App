package com.example.signupvalidationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    TextView tvName, tvEmail, tvPassword, tvCity, tvGender, tvCountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvPassword = findViewById(R.id.tvPassword);
        tvCity = findViewById(R.id.tvCity);
        tvGender = findViewById(R.id.tvGender);
        tvCountry = findViewById(R.id.tvCountry);

        Intent intent = getIntent();

        tvName.setText("Name: " + intent.getStringExtra("name"));
        tvEmail.setText("Email: " + intent.getStringExtra("email"));
        tvPassword.setText("Password: " + intent.getStringExtra("password"));
        tvCity.setText("City: " + intent.getStringExtra("city"));
        tvGender.setText("Gender: " + intent.getStringExtra("gender"));
        tvCountry.setText("Country: " + intent.getStringExtra("country"));
    }
}
